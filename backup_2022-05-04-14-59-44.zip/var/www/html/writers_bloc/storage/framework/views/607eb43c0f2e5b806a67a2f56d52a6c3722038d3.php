<?php $__env->startSection('content'); ?>
<nav class="text-black" aria-label="Breadcrumb">
    <ol class="list-none p-0 inline-flex">
        <li class="flex items-center">
            <a href="/teacher/lesson">Lesson</a>
            <?php if (isset($component)) { $__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Chevron::class, []); ?>
<?php $component->withName('chevron'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918)): ?>
<?php $component = $__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918; ?>
<?php unset($__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </li>
        <li class="flex items-center">
            <a href=<?php echo e(route('teacher-lesson-show',$lesson->id)); ?>><?php echo e($lesson->title); ?></a>
            <?php if (isset($component)) { $__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Chevron::class, []); ?>
<?php $component->withName('chevron'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918)): ?>
<?php $component = $__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918; ?>
<?php unset($__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </li>
        <li class="flex items-center font-bold">
            <a href="#">Add quiz</a>
        </li>
    </ol>
</nav>


<div class="mt-16">

    <form action=<?php echo e(route('teacher-quiz-store',$lesson->id)); ?> method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="grid grid-cols-1 gap-6">
            <label class="block">
                <span class="text-gray-700 font-bold">Quiz Type<span class="text-red-500">*</span></span>
                <select
                    class="mt-1 mb-2 block  w-full rounded-md bg-gray-100 border-transparent focus:border-gray-500 focus:bg-white focus:ring-0"
                    name="type" id="type" onchange="typeChange()">
                    <option selected value="multiple_choice">Multiple Choice</option>
                    <option value="essay">Essay</option>
                </select>
                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label class="block">
                <span class="text-gray-700 font-bold">Quiz question<span class="text-red-500">*</span></span>
                <textarea
                    class="mt-1 mb-2 block  w-full rounded-md bg-gray-100 border-transparent focus:border-gray-500 focus:bg-white focus:ring-0"
                    rows="10" name="question"><?php echo e(old('question')); ?></textarea>
                <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <div class="ml-16" id="choice_container">
                <?php for($i = 0; $i < 4; $i++): ?> <label class="block">
                    <span class="text-gray-700 font-bold">Choice <?php echo e($i + 1); ?> <?php if($i == 0): ?>
                        <span class="text-red-500 text-xs italic">* First
                            choice is always the correct answer</span>
                        <?php endif; ?></span>
                    <input type="text"
                        class="mt-1 mb-2 block w-full rounded-md bg-gray-100 border-transparent focus:border-gray-500 focus:bg-white focus:ring-0"
                        placeholder="" name="choice[]" value="<?php echo e(old('choice.'.$i)); ?>">
                    <?php $__errorArgs = ['choice.'.$i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>
                    <?php endfor; ?>
            </div>
        </div>




        <div class="block">
            <div class="mt-2">
                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-4 px-4 rounded">
                    Save Quiz
                </button>
            </div>
        </div>
    </form>


</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    document.getElementById("type").click()
    const choiceContainer = document.querySelector('#choice_container');
const typeChange = () => {
  const selected_type = document.getElementById("type").value;
console.log(selected_type)
choiceContainer.style.display = selected_type == 'multiple_choice' ? 'block' : 'none'
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/writers_bloc/resources/views/teacher/quiz/create.blade.php ENDPATH**/ ?>