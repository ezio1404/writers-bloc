<?php $__env->startSection('content'); ?>
<main class="pt-20 sm:container sm:mx-auto ">
    <div class="w-full sm:px-6">

        <?php if(session('status')): ?>
        <div class="text-sm border border-t-8 rounded text-green-700 border-green-600 bg-green-100 px-3 py-4 mb-4"
            role="alert">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>

        <section class="flex flex-col break-words bg-white sm:border-1 sm:rounded-md sm:shadow-sm sm:shadow-lg">
            <header class="font-semibold bg-gray-200 text-gray-700 py-5 px-6 sm:py-6 sm:px-8 sm:rounded-t-md">
                Lesson Writing Task
            </header>
            <form action="<?php echo e(route('lesson-writing-task-store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="lesson_id" value="<?php echo e($lesson->id); ?>">
                <div class="grid grid-cols-1 gap-6 p-4 lg:p-10">
                    <?php $__currentLoopData = $lesson->writingTask; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="block">
                        <span class="text-gray-700 font-bold"><?php echo e($task->task); ?><span class="text-red-500">*</span></span>
                        <textarea required name="writingTaskAnswers[<?php echo e($task->id); ?>]"
                            class="form-textarea mt-4 mb-2 block w-full rounded-md bg-gray-100 border-transparent focus:border-gray-500 focus:bg-white focus:ring-0"
                            rows="7"></textarea>
                        <?php if($errors->has("writingTaskAnswers.$task->id")): ?>
                        <span style="margin-top: .25rem; font-size: 80%; color: #e3342f;" role="alert">
                            <strong><?php echo e($errors->first("writingTaskAnswers.$task->id")); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <input
                        class="cursor-pointer bg-blue-500 block w-full  text-white font-bold py-4 px-4 rounded text-center uppercase"
                        type="submit" value="Submit Writing Task Answers">
                </div>
            </form>

        </section>


    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/writers_bloc/resources/views/student/writing/index.blade.php ENDPATH**/ ?>