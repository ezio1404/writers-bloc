<?php $__env->startSection('content'); ?>
<main class="pt-20 sm:container sm:mx-auto ">
    <div class="w-full sm:px-6">

        <?php if(session('status')): ?>
        <div class="text-sm border border-t-8 rounded text-green-700 border-green-600 bg-green-100 px-3 py-4 mb-4"
            role="alert">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>

        <section class="flex flex-col break-words bg-white sm:border-1 sm:rounded-md sm:shadow-sm sm:shadow-lg">
            <header class="font-semibold bg-gray-200 text-gray-700 py-5 px-6 sm:py-6 sm:px-8 sm:rounded-t-md">
                Lesson Quiz
            </header>
            <form action="<?php echo e(route('lesson-quiz-store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="lesson_id" value="<?php echo e($lesson->id); ?>">
                <div class="grid grid-cols-1 gap-6 p-4 lg:p-10">
                    <?php $__currentLoopData = $lesson->quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$quiz->choices->isEmpty()): ?>
                    <div class="block">
                        <span class="text-gray-700 font-bold"><?php echo e($quiz->question); ?><span
                                class="text-red-500">*</span></span>
                        <div class="flex flex-col mt-4">
                            <?php $__currentLoopData = $quiz->choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="p-4 w-full" for="choice-<?php echo e($choice->id); ?>">
                                <input required type="radio" class="form-radio mr-2" name="quizAnswer[<?php echo e($quiz->id); ?>]"
                                    id="choice-<?php echo e($choice->id); ?>" value=<?php echo e($choice->id); ?>>
                                <?php echo e($choice->choice); ?>

                            </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="block">
                        <span class="text-gray-700 font-bold"><?php echo e($quiz->question); ?><span
                                class="text-red-500">*</span></span>
                        <textarea required name="quizAnswer[<?php echo e($quiz->id); ?>]"
                            class="form-textarea mt-4 mb-2 block w-full rounded-md bg-gray-100 border-transparent focus:border-gray-500 focus:bg-white focus:ring-0"
                            rows="7"></textarea>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <input

                        class="cursor-pointer bg-blue-500 block w-full  text-white font-bold py-4 px-4 rounded text-center uppercase"
                        type="submit" value="Submit Quiz Answers">
                </div>
            </form>

        </section>


    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/writers_bloc/resources/views/student/quiz/index.blade.php ENDPATH**/ ?>