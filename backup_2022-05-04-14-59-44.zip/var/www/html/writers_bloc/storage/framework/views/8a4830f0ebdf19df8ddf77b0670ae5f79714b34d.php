<?php $__env->startSection('content'); ?>
<nav class="text-black" aria-label="Breadcrumb">
    <ol class="list-none p-0 inline-flex">
        <li class="flex items-center">
            <a href="<?php echo e(route('teacher-student')); ?>">Student</a>
            <?php if (isset($component)) { $__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Chevron::class, []); ?>
<?php $component->withName('chevron'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918)): ?>
<?php $component = $__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918; ?>
<?php unset($__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </li>
        <li class="flex items-center">
            <a
                href=<?php echo e(route('teacher-show-student',$student->studentLog->user->id)); ?>><?php echo e($student->studentLog->user->name); ?></a>
            <?php if (isset($component)) { $__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Chevron::class, []); ?>
<?php $component->withName('chevron'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918)): ?>
<?php $component = $__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918; ?>
<?php unset($__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </li>
        <li class="flex items-center">
            <a href=#>Grade Writing Task</a>
        </li>
    </ol>
</nav>

<div class="mt-16">

    <div class="mt-10">
        <div class="flex flex-col">
            <div class="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                <div class="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                    <form
                        action=<?php echo e(route('teacher-grade-writing-task-put', ['studentLogId'=> $student->student_log_id,'writingTaskId'=> $student->writingTask->id])); ?>

                        method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="grid grid-cols-1 gap-6">
                            <div class="block">
                                <div class="mt-2">
                                    <label class="mr-4">
                                        <span class="text-gray-700 font-bold">Student Grade<span
                                                class="text-red-500">*</span></span>
                                        <input required type="number" max="<?php echo e($student->writingTask->points); ?>" min="1"
                                            class="mt-1 mb-2 block w-full rounded-md bg-gray-100 border-transparent focus:border-gray-500 focus:bg-white focus:ring-0"
                                            name="grade" id="grade" value=<?php echo e(old('grade') ?? $student->points); ?>>
                                        <?php $__errorArgs = ['grade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-red-500"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <button type="submit"
                                        class="bg-blue-500 hover:bg-blue-700 text-white font-bold p-2 rounded">
                                        Grade Writing Task
                                    </button>
                                </div>
                            </div>
                            <div class="block">
                                <details open>
                                    <summary class="text-gray-700 font-bold cursor-pointer">Writing Task Details <span
                                            class="text-red-500 italic text-sm">click for more Writing task details</span>
                                    </summary>
                                    <label class="mr-4">
                                        <span class="text-gray-700 font-bold">Writing Task Max points
                                            <input type="number" disabled
                                                class="mt-1 mb-2 block w-full rounded-md bg-gray-100 border-transparent focus:border-gray-500 focus:bg-white focus:ring-0"
                                                name="max_points" id="max_points" value=<?php echo e($student->writingTask->points); ?>>
                                            <?php $__errorArgs = ['max_points'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-500"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <label class="block">
                                        <span class="text-gray-700 font-bold">Writing Task
                                            <textarea disabled
                                                class="mt-1 mb-2 block  w-full rounded-md bg-gray-100 border-transparent focus:border-gray-500 focus:bg-white focus:ring-0"
                                                rows="2"> <?php echo e($student->writingTask->task); ?></textarea>

                                    </label>
                                </details>

                            </div>
                            <label class="block">
                                <span class="text-gray-700 font-bold">Student Writing Task Answer
                                    <textarea disabled
                                        class="mt-1 mb-2 block  w-full rounded-md bg-gray-100 border-transparent focus:border-gray-500 focus:bg-white focus:ring-0"
                                        rows="10"> <?php echo e($student->task_answer); ?></textarea>

                            </label>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/writers_bloc/resources/views/teacher/writing/grade/index.blade.php ENDPATH**/ ?>