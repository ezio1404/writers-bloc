<?php $__env->startSection('content'); ?>
<main class="sm:container sm:mx-auto pt-20">
    <div class="w-full sm:px-6">

        <?php if(session('status')): ?>
        <div class="text-sm border border-t-8 rounded text-green-700 border-green-600 bg-green-100 px-3 py-4 mb-4"
            role="alert">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>

        <section class="flex flex-col break-words bg-white sm:border-1 sm:rounded-md sm:shadow-sm sm:shadow-lg">
            <header class="font-semibold bg-gray-200 text-gray-700 py-5 px-6 sm:py-6 sm:px-8 sm:rounded-t-md">
                Announcements
            </header>
        </section>
        <div class="container mx-auto my-5 grid grid-flow-row grid-cols-1 gap-4 ">
            <div class="container mx-auto my-5 grid grid-flow-row grid-cols-1 gap-4 ">
                <?php $__empty_1 = true; $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <!-- This is an example component -->
                <?php if (isset($component)) { $__componentOriginal3c35ee6afd3809180db3a3b1cd29a407711110fc = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardComponent::class, ['announcement' => $announcement]); ?>
<?php $component->withName('card-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal3c35ee6afd3809180db3a3b1cd29a407711110fc)): ?>
<?php $component = $__componentOriginal3c35ee6afd3809180db3a3b1cd29a407711110fc; ?>
<?php unset($__componentOriginal3c35ee6afd3809180db3a3b1cd29a407711110fc); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="max-w-xs sm:max-w-sm mt-8 mx-auto bg-grey-light rounded-lg shadow p-8">
                    <h2 class="italic text-right text-blue-darkest leading-normal">
                        Do something now; your future self will thank you for later
                    </h2>
                    <p class="text-center pt-8 text-grey-darker">
                        - Someone Great
                    </p>
                </div>
                <?php endif; ?>
            </div>

        </div>


    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/writers_bloc/resources/views/welcome.blade.php ENDPATH**/ ?>