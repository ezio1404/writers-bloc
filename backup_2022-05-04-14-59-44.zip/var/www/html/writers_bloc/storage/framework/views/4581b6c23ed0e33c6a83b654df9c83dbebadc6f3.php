<?php $__env->startSection('content'); ?>
<main class="sm:container sm:mx-auto pt-20">
    <div class="w-full sm:px-6">

        <?php if(session('status')): ?>
        <div class="text-sm border border-t-8 rounded text-green-700 border-green-600 bg-green-100 px-3 py-4 mb-4"
            role="alert">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>

        <section class="flex flex-col break-words bg-white sm:border-1 sm:rounded-md sm:shadow-sm sm:shadow-lg">
            <header class="font-semibold bg-gray-200 text-gray-700 py-5 px-6 sm:py-6 sm:px-8 sm:rounded-t-md">
                Settings
            </header>

            <div class="py-20">
                <div class="mx-auto w-10/12">
                    <form action="<?php echo e(route('student-update-password')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="flex items-baseline flex-col lg:flex-row">
                            <label class="block w-full lg:w-1/2  py-4">
                                <span class="text-gray-700 text-2xl font-bold">Change Password</span>
                            </label>
                            <div class="block w-full lg:w-1/2">
                                <label for="current_password" class="block py-4 text-gray-700 font-bold"> <span
                                        class="text-gray-700 font-bold">Old Password</span>
                                    <input type="password"
                                        class="mt-1 form-password mb-2 block w-full rounded-md bg-gray-100 border-transparent focus:border-gray-500 focus:bg-white focus:ring-0"
                                        placeholder="Current Password" id="current_password" name="current_password"
                                        value="<?php echo e(old('current_password')); ?>">
                                    <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </label>
                                <label for="new_password" class="block py-4  text-gray-700 font-bold"> <span
                                        class="text-gray-700 font-bold">New Password</span>
                                    <input type="password"
                                        class="mt-1 form-password mb-2 block w-full rounded-md bg-gray-100 border-transparent focus:border-gray-500 focus:bg-white focus:ring-0"
                                        placeholder="New Password" id="new_password" name="new_password"
                                        value="<?php echo e(old('new_password')); ?>">
                                    <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </label>
                                <label for="new_password_confirmation" class="block py-4  text-gray-700 font-bold">
                                    <span class="text-gray-700 font-bold">Confirm Password</span>
                                    <input type="password"
                                        class="mt-1 form-password mb-2 block w-full rounded-md bg-gray-100 border-transparent focus:border-gray-500 focus:bg-white focus:ring-0"
                                        placeholder="Confirm Password" id="new_password_confirmation"
                                        name="new_password_confirmation" value="<?php echo e(old('new_password_confirmation')); ?>">
                                    <?php $__errorArgs = ['new_password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </label>
                            </div>
                        </div>
                        <div class="flex flex-row-reverse">
                            <div class="">
                                <input type="submit" class="cursor-pointer p-4 rounded hover:bg-blue-100 "
                                    value="Change Password">
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </section>


    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/writers_bloc/resources/views/student/settings.blade.php ENDPATH**/ ?>