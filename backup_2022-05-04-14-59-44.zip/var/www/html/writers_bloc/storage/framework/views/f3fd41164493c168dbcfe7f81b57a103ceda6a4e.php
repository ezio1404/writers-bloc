<?php $__env->startSection('style'); ?>
<style>
    body {
        font-family: Arial;
    }

    /* Style the tab */
    .tab {
        overflow: hidden;
        border: 1px solid #ccc;
        background-color: #f1f1f1;
    }

    /* Style the buttons inside the tab */
    .tab a {
        background-color: inherit;
        float: left;
        border: none;
        outline: none;
        cursor: pointer;
        padding: 14px 16px;
        transition: 0.3s;
        font-size: 17px;
    }

    /* Change background color of as on hover */
    .tab a:hover {
        background-color: #ddd;
    }

    /* Create an active/current tablink class */
    .tab a.active {
        background-color: #ccc;
    }

    /* Style the tab content */
    .tabcontent {
        display: none;
        padding: 6px 12px;


    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<nav class="text-black" aria-label="Breadcrumb">
    <ol class="list-none p-0 inline-flex">
        <li class="flex items-center">
            <a href="/teacher/lesson">Lesson</a>
            <?php if (isset($component)) { $__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Chevron::class, []); ?>
<?php $component->withName('chevron'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918)): ?>
<?php $component = $__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918; ?>
<?php unset($__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </li>
        <li class="flex items-center">
            <a
                href="<?php echo e(route('teacher-quiz-show',['lessonId' =>  $lesson->id, 'quizId' => $lesson->quiz->id])); ?>"><?php echo e($lesson->quiz->question); ?></a>
            <?php if (isset($component)) { $__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Chevron::class, []); ?>
<?php $component->withName('chevron'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918)): ?>
<?php $component = $__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918; ?>
<?php unset($__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </li>
        <li class="flex items-center font-bold">
            <a href="#"><?php echo e($lesson->quiz->choices[0]->choice); ?></a>
        </li>
    </ol>
</nav>

<nav class="tab flex mt-8 text-center">
    <a href="<?php echo e(route('teacher-lesson-show',$lesson->id)); ?>"
        class="tablinks w-full <?php if(Route::currentRouteName() == 'teacher-lesson-show'): ?> active <?php endif; ?>">Discussion</a>
    <a href="<?php echo e(route('teacher-quiz',$lesson->id)); ?>"
        class="tablinks w-full <?php if(Route::currentRouteName() == 'teacher-quiz' || Route::currentRouteName() == 'teacher-choice-show'): ?> active <?php endif; ?>">Quiz</a>
    <a href="<?php echo e(route('teacher-writing',$lesson->id)); ?>"
        class="tablinks w-full <?php if(Route::currentRouteName() == 'teacher-writing-show'): ?> active <?php endif; ?>">Writing
        Task</a>
</nav>




<div class="mt-8">
    <form action=<?php echo e(route('teacher-choice-put', $lesson->quiz->choices[0]->id)); ?> method="POST"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <input type="hidden" name="lesson_id" value="<?php echo e($lesson->id); ?>">
        <input type="hidden" name="quiz_id" value="<?php echo e($lesson->quiz->id); ?>">
        <div class="grid grid-cols-1 gap-6">
            <?php if($lesson->quiz->choices[0]->is_correct_choice ): ?>
            <div class="bg-red-100 p-4 rounded">
                <span class="text-red-500 font-medium">You are updating the correct answer, please be way of your
                    changes</span>
            </div>
            <?php endif; ?>
            <label class="block">
                <span class="text-gray-700 font-bold">Choice</span>
                <input type="text"
                    class="mt-1 mb-2 block w-full rounded-md bg-gray-100 border-transparent focus:border-gray-500 focus:bg-white focus:ring-0"
                    placeholder="" name="choice" value="<?php echo e(old('choice') ??  $lesson->quiz->choices[0]->choice); ?>">
                <?php $__errorArgs = ['choice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <div class="block">
                <div class="mt-2">
                    <a class="bg-yellow-300 hover:bg-yellow-400 text-white font-bold py-4 px-4 rounded"
                        href="<?php echo e(route('teacher-quiz-show',['lessonId' =>  $lesson->id, 'quizId' => $lesson->quiz->id])); ?>">Cancel
                        Update</a>
                    <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-4 px-4 rounded">
                        Update Choice
                    </button>
                </div>

            </div>
        </div>

    </form>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/writers_bloc/resources/views/teacher/choice/show.blade.php ENDPATH**/ ?>