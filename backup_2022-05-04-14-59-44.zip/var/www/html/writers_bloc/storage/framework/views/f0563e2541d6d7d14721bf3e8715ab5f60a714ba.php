<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js" defer></script>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <!-- Filepond stylesheet -->
    <link href="https://unpkg.com/filepond/dist/filepond.css" defer rel="stylesheet">
    <!-- Styles -->
    <link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body class="bg-gray-100 h-screen antialiased  font-sans">
    <div id="app">
        <?php if (isset($component)) { $__componentOriginal32da9b408f3ca35924884d875dd05cda6e72bd5a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TeacherNavbar::class, []); ?>
<?php $component->withName('teacher-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal32da9b408f3ca35924884d875dd05cda6e72bd5a)): ?>
<?php $component = $__componentOriginal32da9b408f3ca35924884d875dd05cda6e72bd5a; ?>
<?php unset($__componentOriginal32da9b408f3ca35924884d875dd05cda6e72bd5a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <div class="flex flex-wrap bg-gray-100 w-full h-screen">
            <div class="w-9/12 ml-1/4">
                <div class="p-4 text-gray-500">
                    <div class="bg-white p-4 rounded">

                        <?php echo $__env->yieldContent('content'); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://unpkg.com/filepond/dist/filepond.js"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH /var/www/html/writers_bloc/resources/views/layouts/teacher.blade.php ENDPATH**/ ?>