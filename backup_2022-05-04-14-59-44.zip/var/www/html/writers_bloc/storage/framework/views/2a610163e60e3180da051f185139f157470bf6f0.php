<label class="block">
    <span class="text-gray-700 font-bold"><?php echo e($title); ?><span class="text-red-500">*</span></span>
    <input type="text"
        class="mt-1 mb-2 block w-full rounded-md bg-gray-100 border-transparent focus:border-gray-500 focus:bg-white focus:ring-0"
        placeholder="" name="<?php echo e($field); ?>" value="<?php echo e(old($field) ?? $value); ?>">
    <?php $__errorArgs = [$field ];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-red-500"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</label>
<?php /**PATH /var/www/html/writers_bloc/resources/views/components/student-input-component.blade.php ENDPATH**/ ?>