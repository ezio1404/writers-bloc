<?php $__env->startSection('content'); ?>
<main class="sm:container sm:mx-auto pt-20">
    <div class="w-full sm:px-6">

        <?php if(session('status')): ?>
        <div class="text-sm border border-t-8 rounded text-green-700 border-green-600 bg-green-100 px-3 py-4 mb-4"
            role="alert">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>

        <section class="flex flex-col break-words bg-white sm:border-1 sm:rounded-md sm:shadow-sm sm:shadow-lg">
            <header class="font-semibold bg-gray-200 text-gray-700 py-5 px-6 sm:py-6 sm:px-8 sm:rounded-t-md">
                Lesson List
            </header>
        </section>
        <div class="container mx-auto my-5 grid grid-flow-row grid-cols-1 gap-4 ">
            <?php $__empty_1 = true; $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <!-- This is an example component -->
            <div class="container mx-auto my-5">

                <div class="relative rounded-lg flex flex-col md:flex-row items-center md:shadow-xl md:h-72 mx-2">

                    <div
                        class="z-0 order-1 md:order-2 relative w-full md:w-2/5 h-80 md:h-full overflow-hidden rounded-lg md:rounded-none md:rounded-r-lg">
                        <div class="absolute inset-0 w-full h-full object-fill object-center bg-blue-400 bg-opacity-30 bg-cover bg-bottom"
                            style="background-image: url( <?php echo e(asset('images/login-bg.jpg')); ?> ); background-blend-mode: multiply;">
                        </div>
                        <div
                            class="md:hidden absolute inset-0 h-full p-6 pb-6 flex flex-col-reverse justify-start items-start bg-gradient-to-b from-transparent via-transparent to-gray-900">
                            <h3 class="w-full font-bold text-2xl text-white leading-tight mb-2"><?php echo e($lesson->title); ?>

                            </h3>
                            <h4 class="w-full text-xl text-gray-100 leading-tight">
                                <?php echo e($lesson->publish_date->toFormattedDateString()); ?></h4>
                        </div>
                        <svg class="hidden md:block absolute inset-y-0 h-full w-24 fill-current text-white -ml-12"
                            viewBox="0 0 100 100" preserveAspectRatio="none">
                            <polygon points="50,0 100,0 50,100 0,100" />
                        </svg>
                    </div>

                    <div class="z-10 order-2 md:order-1 w-full h-full md:w-3/5 flex items-center -mt-6 md:mt-0">
                        <div
                            class="w-full p-8 md:pr-18 md:pl-14 md:py-12 mx-2 md:mx-0 h-full bg-white rounded-lg md:rounded-none md:rounded-l-lg shadow-xl md:shadow-none">
                            <h4 class="hidden md:block text-xl text-gray-400">
                                <?php echo e($lesson->publish_date->toFormattedDateString()); ?>


                            </h4>
                            <h3 class="hidden md:block font-bold text-2xl text-gray-700"><?php echo e($lesson->title); ?> </h3>
                            <p class="py-2 text-gray-600 text-justify"><?php echo e(Str::words($lesson->discussion , 40, '  . . .')); ?></p>
                            <a class="absolute bottom-0 pb-4 flex items-baseline mt-3 text-blue-600 hover:text-blue-900 focus:text-blue-900"
                                href=<?php echo e(route('lesson-details',$lesson->id)); ?>>
                                <span>Learn more</span>
                                <span class="text-xs ml-1">&#x279c;</span>
                            </a>
                        </div>
                    </div>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="max-w-xs sm:max-w-sm mt-8 mx-auto bg-grey-light rounded-lg shadow p-8">
                <h2 class="italic text-right text-blue-darkest leading-normal">
                    Do something now; your future self will thank you for later
                </h2>
                <p class="text-center pt-8 text-grey-darker">
                    - Someone Great
                </p>
            </div>
            <?php endif; ?>
        </div>


    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/writers_bloc/resources/views/student/lessons.blade.php ENDPATH**/ ?>