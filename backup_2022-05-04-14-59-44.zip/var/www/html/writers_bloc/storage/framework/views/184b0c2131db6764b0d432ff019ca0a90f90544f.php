<?php $__env->startSection('content'); ?>
<nav class="text-black" aria-label="Breadcrumb">
    <ol class="list-none p-0 inline-flex">
        <li class="flex items-center">
            <a href="<?php echo e(route('teacher-student')); ?>">Student</a>
            <?php if (isset($component)) { $__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Chevron::class, []); ?>
<?php $component->withName('chevron'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918)): ?>
<?php $component = $__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918; ?>
<?php unset($__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </li>
        <li class="flex items-center">
            <a href=<?php echo e(route('teacher-show-student', ['userId'=>$student->id])); ?>><?php echo e($student->name); ?></a>
            <?php if (isset($component)) { $__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Chevron::class, []); ?>
<?php $component->withName('chevron'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918)): ?>
<?php $component = $__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918; ?>
<?php unset($__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </li>
        <li class="flex items-center">
            <a href="#">Grade Lesson</a>
        </li>
    </ol>
</nav>

<div class="mt-16">


    <div class="mt-10">
        <div class="flex flex-col">
            <div class="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                <div class="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                    <div class="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                        <?php $__empty_1 = true; $__currentLoopData = $student->studentLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentLogs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="p-4">
                            <h1 class="font-bold text-2xl text-gray-900"><?php echo e($studentLogs->lesson->title); ?></h1>
                            <div class="ml-10">
                                <h1 class="font-bold text-xl">Quiz</h1>
                                <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th scope="col"
                                                class="w-1/3 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                Quiz Question
                                            </th>
                                            <th scope="col"
                                                class="w-1/2 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                Answer
                                            </th>
                                            <th scope="col"
                                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                Points
                                            </th>
                                            <th scope="col" class="relative px-6 py-3">
                                                <span class="sr-only">Edit</span>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody class="bg-white divide-y divide-gray-200">
                                        <?php $__empty_2 = true; $__currentLoopData = $studentLogs->studentQuizAnswer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentQuizAnswer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap ">
                                                <div class="text-sm font-medium text-gray-900">
                                                    
                                                    <?php echo e($studentQuizAnswer->quiz->question); ?>

                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap w-1/2">
                                                <span
                                                    class="text-xs leading-snug"><?php echo e($studentQuizAnswer->quiz->type == 'multiple_choice'? 'Multiple Choice': 'Essay'); ?></span>
                                                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([ 'text-large font-bold text-gray-900' , 'text-red-500'=>
                                                    $studentQuizAnswer->points === 0,
                                                    'text-green-500' => $studentQuizAnswer->points
                                                    ]) ?>">
                                                    <?php echo e($studentQuizAnswer->answer); ?>

                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm text-gray-900">
                                                    <?php echo e($studentQuizAnswer->points ?? '-'); ?>

                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium flex">
                                                <?php if($studentQuizAnswer->quiz->type == 'essay'): ?>
                                                <a href="<?php echo e(route('teacher-grade-quiz',['studentLogId' => $student->studentLogs->first()->id, 'quizId' => $studentQuizAnswer->quiz->id])); ?>"
                                                    class="text-indigo-600 hover:text-indigo-900 bg-indigo-100 p-2 rounded mr-2">
                                                    Grade</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php if($loop->last): ?>
                                        <tr>
                                            <td></td>
                                            <td class="px-6 py-4 whitespace-nowrap w-1/2">
                                                <div class="text-sm text-gray-900">Total Points</div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm text-gray-900">
                                                    <?php echo e($studentLogs->student_quiz_answer_sum_points); ?> </div>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap" colspan="3">
                                                <div class="text-large font-medium text-gray-900 text-center">
                                                    Empty Quiz Answers
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>

                            </div>

                            <div class="ml-10">
                                <h1 class="font-bold text-xl">Writing Task</h1>
                                <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th scope="col"
                                                class="w-1/3  px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                Writing Task
                                            </th>
                                            <th scope="col"
                                                class="w-1/2 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                Answer
                                            </th>
                                            <th scope="col"
                                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                Points
                                            </th>
                                            <th scope="col" class="relative px-6 py-3">
                                                <span class="sr-only">Edit</span>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody class="bg-white divide-y divide-gray-200">
                                        <?php $__empty_2 = true; $__currentLoopData = $studentLogs->studentWritingTaskAnswer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentWritingTaskAnswer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm font-medium text-gray-900">
                                                    <?php echo e($studentWritingTaskAnswer->writingTask->task); ?>

                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-large font-bold text-gray-900">
                                                    <?php echo e($studentWritingTaskAnswer->task_answer); ?>

                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm text-gray-900">
                                                    <?php echo e($studentWritingTaskAnswer->points ?? '-'); ?>

                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium flex">
                                                <a href="<?php echo e(route('teacher-grade-writing-task',['studentLogId' => $student->studentLogs->first()->id, 'writingTaskId' => $studentWritingTaskAnswer->writingTask->id])); ?>"
                                                    class="text-indigo-600 hover:text-indigo-900 bg-indigo-100 p-2 rounded mr-2">
                                                    Grade</a>
                                            </td>
                                        </tr>
                                        <?php if($loop->last): ?>
                                        <tr>
                                            <td></td>
                                            <td class="px-6 py-4 whitespace-nowrap w-1/2">
                                                <div class="text-sm text-gray-900">Total Points</div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="text-sm text-gray-900">
                                                    <?php echo e($studentLogs->student_writing_task_answer_sum_points ?? '-'); ?>

                                                </div>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap" colspan="4">
                                                <div class="text-large font-medium text-gray-900 text-center">
                                                    Empty Writing Task Answers
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/writers_bloc/resources/views/teacher/student/lesson.blade.php ENDPATH**/ ?>