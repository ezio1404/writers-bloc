<?php $__env->startSection('content'); ?>
<nav class="text-black" aria-label="Breadcrumb">
    <ol class="list-none p-0 inline-flex">
        <li class="flex items-center">
            <a href="<?php echo e(route('teacher-student')); ?>">Student</a>
            <?php if (isset($component)) { $__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Chevron::class, []); ?>
<?php $component->withName('chevron'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918)): ?>
<?php $component = $__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918; ?>
<?php unset($__componentOriginal2e4a7f2957b8a29feb3ba88127b6ec4093b54918); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </li>
        <li class="flex items-center font-bold">
            <a href="#">Edit Student</a>
        </li>
    </ol>
</nav>


<div class="mt-16">
    <h1 class="mb-12"><?php echo e($user->name); ?></h1>
    <form action=<?php echo e(route('teacher-student-update', $user)); ?> method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="grid grid-cols-1 gap-6">
            <?php if (isset($component)) { $__componentOriginald0e11447e126c86177b7958cc3f029c3c5aac678 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\StudentInputComponent::class, ['title' => 'Firstname','field' => 'firstname','value' => ''.e($user->firstname).'']); ?>
<?php $component->withName('student-input-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald0e11447e126c86177b7958cc3f029c3c5aac678)): ?>
<?php $component = $__componentOriginald0e11447e126c86177b7958cc3f029c3c5aac678; ?>
<?php unset($__componentOriginald0e11447e126c86177b7958cc3f029c3c5aac678); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginald0e11447e126c86177b7958cc3f029c3c5aac678 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\StudentInputComponent::class, ['title' => 'Lastname','field' => 'lastname','value' => ''.e($user->lastname).'']); ?>
<?php $component->withName('student-input-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald0e11447e126c86177b7958cc3f029c3c5aac678)): ?>
<?php $component = $__componentOriginald0e11447e126c86177b7958cc3f029c3c5aac678; ?>
<?php unset($__componentOriginald0e11447e126c86177b7958cc3f029c3c5aac678); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginald0e11447e126c86177b7958cc3f029c3c5aac678 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\StudentInputComponent::class, ['title' => 'Email','field' => 'email','value' => ''.e($user->email).'']); ?>
<?php $component->withName('student-input-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald0e11447e126c86177b7958cc3f029c3c5aac678)): ?>
<?php $component = $__componentOriginald0e11447e126c86177b7958cc3f029c3c5aac678; ?>
<?php unset($__componentOriginald0e11447e126c86177b7958cc3f029c3c5aac678); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>

        <div class="block">
            <div class="mt-2">
                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-4 px-4 rounded">
                    Save Student
                </button>
            </div>
        </div>
    </form>


</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/writers_bloc/resources/views/teacher/student/showStudent.blade.php ENDPATH**/ ?>