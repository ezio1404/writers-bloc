<?php

use App\Http\Controllers\AnnouncementController;
use App\Http\Controllers\ChoiceController;
use App\Http\Controllers\LessonController;
use App\Http\Controllers\QuizController;
use App\Http\Controllers\TeacherController;
use App\Http\Controllers\UploadController;
use App\Http\Controllers\WritingController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LessonQuizController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\StudentAnnouncementController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\StudentLessonController;
use App\Http\Controllers\StudentWritingTaskController;
use App\Http\Controllers\UserSettingsContoller;
use App\Mail\AnnouncementMail;
use App\Models\Lesson;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', [HomeController::class, 'slash']);
Route::get('/announcementMail',function(){
    return new AnnouncementMail();
});

Auth::routes();



Route::group(['middleware' => ['role:student|teacher', 'auth']], function () {
    Route::get('/home', [HomeController::class, 'index'])->name('home');
    Route::get('/lessons', [HomeController::class, 'lessons'])->name('lessons');
    Route::get('/settings', [HomeController::class, 'settings'])->name('student-settings');
    Route::post('/settings/update-password', [UserSettingsContoller::class, 'updatePassword'])->name('student-update-password');
    Route::prefix('lesson')->group(function () {
        Route::get('/{lessonId}', [StudentLessonController::class, 'index'])->name('lesson-details');
        Route::prefix('quiz')->group(function () {
            Route::get('/{lessonId}', [LessonQuizController::class, 'index'])->name('lesson-quiz');
            Route::post('/', [LessonQuizController::class, 'store'])->name('lesson-quiz-store');
        });
        Route::prefix('writing-task')->group(function () {
            Route::get('/{lessonId}', [StudentWritingTaskController::class, 'index'])->name('lesson-writing-task');
            Route::post('/', [StudentWritingTaskController::class, 'store'])->name('lesson-writing-task-store');
        });
    });
    Route::prefix('announcement')->group(function () {
        Route::get('/{announcement}', [StudentAnnouncementController::class, 'show'])->name('announcement-student-show');
    });
});

Route::group(['middleware' => ['role:teacher', 'auth']], function () {
    Route::prefix('teacher')->group(function () {
        Route::get('/', [TeacherController::class, 'dashboard'])->name('teacher-home');
        Route::post('/student/import', [TeacherController::class, 'import'])->name('import');

        Route::prefix('student')->group(function () {
            Route::get('/', [TeacherController::class, 'index'])->name('teacher-student');
            Route::get('/create', [StudentController::class, 'create'])->name('teacher-student-create');
            Route::post('/saveStudent', [StudentController::class, 'store'])->name('teacher-student-store');
            Route::get('/show/{user}', [StudentController::class, 'show'])->name('teacher-student-show');
            Route::put('/update/{user}', [StudentController::class, 'update'])->name('teacher-student-update');
            Route::delete('/destroy/{id}', [StudentController::class, 'destroy'])->name('teacher-student-destroy');
            Route::post('/restore/{id}', [StudentController::class, 'restore'])->name('teacher-student-restore');
            Route::get('/{userId}', [TeacherController::class, 'show'])->name('teacher-show-student');
            Route::get('/{userId}/{lessonId}/answer', [TeacherController::class, 'studentLesson'])->name('teacher-show-student-lesson');
            Route::get('/{studentLogId}/{quizId}', [TeacherController::class, 'gradeQuizShow'])->name('teacher-grade-quiz');
            Route::put('/{studentLogId}/{quizId}', [TeacherController::class, 'gradeQuizPut'])->name('teacher-grade-quiz-put');
            Route::get('/{studentLogId}/writing-task/{writingTaskId}', [TeacherController::class, 'gradeWritingTaskShow'])->name('teacher-grade-writing-task');
            Route::put('/{studentLogId}/writing-task/{writingTaskId}', [TeacherController::class, 'gradeWritingTaskPut'])->name('teacher-grade-writing-task-put');
        });

        // Report
        Route::prefix('report')->group(function () {
            Route::get('/', [ReportController::class, 'index'])->name('teacher-report');
            Route::get('/students', [ReportController::class, 'getStudents'])->name('teacher-report-getStudents');
        });
        // lesson
        Route::prefix('lesson')->group(function () {
            Route::get('/', [LessonController::class, 'index'])->name('teacher-lesson');
            Route::get('/create', [LessonController::class, 'create'])->name('teacher-lesson-create');
            Route::post('/', [LessonController::class, 'store'])->name('teacher-lesson-store');
            Route::get('/{id}', [LessonController::class, 'show'])->name('teacher-lesson-show');
            Route::put('/{id}', [LessonController::class, 'put'])->name('teacher-lesson-put');
            Route::delete('/{id}', [LessonController::class, 'destroy'])->name('teacher-lesson-destroy');
        });

        Route::prefix('quiz')->group(function () {
            Route::get('/{lessonId}', [QuizController::class, 'index'])->name('teacher-quiz');
            Route::get('/create/{lessonId}', [QuizController::class, 'create'])->name('teacher-quiz-create');
            Route::post('/{lessonId}', [QuizController::class, 'store'])->name('teacher-quiz-store');
            Route::get('{lessonId}/details/{quizId}', [QuizController::class, 'show'])->name('teacher-quiz-show');
            Route::put('/details/{quizId}', [QuizController::class, 'put'])->name('teacher-quiz-put');
            Route::delete('/{quizId}', [QuizController::class, 'destroy'])->name('teacher-quiz-destroy');
        });

        Route::prefix('choice')->group(function () {
            Route::get('{lessonId}/details/{quizId}/{choiceId}', [ChoiceController::class, 'show'])->name('teacher-choice-show');
            Route::put('/choice/{choiceId}', [ChoiceController::class, 'put'])->name('teacher-choice-put');
        });

        Route::prefix('writing')->group(function () {
            Route::get('/{lessonId}', [WritingController::class, 'index'])->name('teacher-writing');
            Route::get('/create/{lessonId}', [WritingController::class, 'create'])->name('teacher-writing-create');
            Route::post('/{lessonId}', [WritingController::class, 'store'])->name('teacher-writing-store');
            Route::get('{lessonId}/{writingTaskId}', [WritingController::class, 'show'])->name('teacher-writing-show');
            Route::put('/details/{writingTaskId}', [WritingController::class, 'put'])->name('teacher-writing-put');
            Route::delete('/{writingTaskId}', [WritingController::class, 'destroy'])->name('teacher-writing-destroy');
        });

        Route::prefix('announcement')->group(function () {
            Route::get('/', [AnnouncementController::class, 'index'])->name('teacher-announcement');
            Route::get('/create', [AnnouncementController::class, 'create'])->name('teacher-announcement-create');
            Route::post('/', [AnnouncementController::class, 'store'])->name('teacher-announcement-store');
            Route::get('/{id}', [AnnouncementController::class, 'show'])->name('teacher-announcement-show');
            Route::put('/{id}', [AnnouncementController::class, 'put'])->name('teacher-announcement-put');
            Route::delete('/{id}', [AnnouncementController::class, 'destroy'])->name('teacher-announcement-destroy');
            Route::post('/restore/{id}', [AnnouncementController::class, 'restore'])->name('teacher-announcement-restore');
        });
    });

    Route::post('/upload', [UploadController::class, 'store']);
});
